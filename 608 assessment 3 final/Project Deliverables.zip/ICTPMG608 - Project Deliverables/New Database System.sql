-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 09, 2019 at 08:50 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `troy_financials`
--

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `AuthorID` int(11) DEFAULT NULL,
  `Author` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`AuthorID`, `Author`) VALUES
(1, 'Gary B. Shelly, Thomas J. Cashman, Dolores Wells'),
(2, 'Mitch Geller, Kelly Hart'),
(3, 'Joline Morrison, Mike Morrison'),
(4, 'Katie Kalata'),
(5, 'Phil Cowcill'),
(6, 'Xue Bai'),
(7, 'Jim Shuman'),
(8, 'Scott Korb'),
(9, 'Bruce McLaren, Constance McLaren'),
(10, 'Napier, Judd, Rivers, Adams'),
(11, 'Michael'),
(12, 'Somebody else'),
(13, 'What number am I?'),
(14, 'A new Author'),
(4523, 'efa'),
(23123, 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `booklist`
--

DROP TABLE IF EXISTS `booklist`;
CREATE TABLE IF NOT EXISTS `booklist` (
  `ID` int(11) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `AuthorID` int(11) DEFAULT NULL,
  `PublisherID` int(11) DEFAULT NULL,
  `Description` mediumtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booklist`
--

INSERT INTO `booklist` (`ID`, `ISBN`, `Title`, `AuthorID`, `PublisherID`, `Description`) VALUES
(1, '0-7895-6539-0', 'Macromedia Dreamweaver MX Introductory Concepts and Techniques', 1, 1, 'Using the Shelly Cashman Series step-by-step, screen-by-screen proven approach to learning, students of all levels will stay on track while learning the latest Dreamweaver MX skills. Starting from scratch, each user will build a fully functional web site in the Dreamweaver MX environment that they can easily incorporate into their Web portfolio. Dreamweaver MX is the latest in building Web sites and Internet applications, and using texts from the Shelly Cashman Series is your solution to teaching it!'),
(2, '0-619-10117-2', 'New Perspectives on Macromedia Dreamweaver - Introductory', 2, 1, 'Introducing Macromedia Dreamweaver\r\n2. Creating More Sophisticated Pages with Tables and Mouse-overs\r\n3. Planning and Design of Sites created with Dreamweaver\r\n4. Shared Site Formatting using the Navigation Bar Object and Frames\r\n5. Using Layers for Page Layout and Functionality\r\n6. Dynamic HTML: Animating with Layers and Behaviors'),
(3, '0-619-06448-X', 'Database-Driven Web Sites, Second Edition', 3, 1, 'Learn to build and deploy dynamic Web applications that interact with a powerful database. Readers with two prior programming courses will learn to get the most out of Visual Studio .NET, Oracle9i and Microsoft Access 2002.'),
(4, '0-619-06321-1', 'Introduction to ASP.NET', 4, 1, 'This is the next generation of Active Server Pages! Revolutionizing the way Web applications are developed, ASP.NET is built on Microsoft\'s .NET framework. This exciting new book seamlessly guides the reader from beginning Web applications, to object-oriented programming, to using advanced Web form server controls.'),
(5, '0-619-06487-0', 'Application Develolpment with Dreamweaver MX using ASP.NET', 5, 1, 'Learn how to develop complex ASP.NET web applications without having to code by hand.  Use the feature rich behaviors provided by Dreamweaver MX to rapidly develop your web applications.'),
(6, '0-619-06343-2', 'JavaServer Pages™', 6, 1, 'Students learn to quickly and easily maintain information-rich, dynamic Web pages using the JavaServer Pages technology. This text covers both the beginning and more advanced JSP topics, from beginning techniques such as Client-side and Server-side Scripting through database access from JSP.'),
(7, '0-619-11052-X', 'Multimedia Concepts, Enhanced Edition - Illustrated Introductory', 7, 1, NULL),
(8, '0-538-71803-X', 'Exploring Desktop Publishing: A Projects Approach', 8, 1, NULL),
(9, '0-619-05942-7', 'E-Commerce BASICS, 2nd Edition', 9, 1, 'This text shows how fundamental business concepts apply to the world of e-commerce. It covers personal applications such as online banking, retail purchasing, and consumer education as well as business applications such as Internet marketing, advertising, and security.'),
(10, '0-619-06319-X', 'E-Business Technologies', 10, 1, 'An essential guide for anyone looking to take the next steps in launching a successful online business, this book focuses on integrating cutting edge technology with E-commerce tactical and strategic skills.'),
(11, 'klsdfaklsdfajkl', 'A new book', 11, 2, 'This is a new book we hope...'),
(12, '01220-021-22', 'i love my bread', 2, 2, 'very good bread'),
(123123, NULL, 'asdasdase', 1, 1, NULL),
(123124, 'what is an isbn?', 'this is a title', 14, 126, 'This is a description for a book.'),
(123125, '8934jksdf', 'This is a book', 14, 126, 'This is published by 126 and written by 14');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
CREATE TABLE IF NOT EXISTS `publisher` (
  `PublisherID` int(11) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`PublisherID`, `Publisher`) VALUES
(1, 'Course Technology'),
(2, 'new'),
(3, 'DAVID JONES'),
(11, 'Jack Daniels'),
(123, 'gegegher'),
(124, 'what numebr'),
(125, 'the next number is...'),
(126, 'Yet another publiser'),
(127, 'Microsoft books');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
